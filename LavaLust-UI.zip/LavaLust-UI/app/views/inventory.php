<?php include 'templates/header.php'; ?>
<?php include 'templates/sidenav.php'; ?>

<div class="container mt-5">
    <h1>Inventory Management</h1>
    <p>Welcome to the inventory management page!</p>
</div>
