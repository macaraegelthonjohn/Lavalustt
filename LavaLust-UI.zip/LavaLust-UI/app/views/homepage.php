<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VapeTrack CIOS - Homepage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .hero {
            background: linear-gradient(135deg, #333, #555);
            color: #fff;
            padding: 5rem 1rem;
            text-align: center;
        }
        .hero h1 {
            font-size: 3.5rem;
            font-weight: bold;
            margin-bottom: 1rem;
        }
        .hero p {
            font-size: 1.25rem;
        }
        .btn-custom {
            background-color: #ff6f61;
            color: #fff;
            border: none;
        }
        .btn-custom:hover {
            background-color: #e65a50;
        }
        .features {
            padding: 4rem 1rem;
        }
        .features .icon {
            font-size: 3rem;
            color: #ff6f61;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>

<!-- Hero Section -->
<div class="hero">
    <h1>Welcome to VapeTrack CIOS</h1>
    <p>Your one-stop solution for managing vape shop inventory and sales with ease.</p>
    <a href="/auth/login" class="btn btn-custom btn-lg mt-3">Get Started</a>
</div>

<!-- Features Section -->
<div class="features container text-center">
    <div class="row">
    <div class="col-md-4">
    <a href="/inventory" style="text-decoration: none; color: inherit;">
        <div class="icon mb-3">💼</div>
        <h3>Inventory Management</h3>
        <p>Track and update your product stock effortlessly.</p>
    </a>
</div>
        <div class="col-md-4">
            <div class="icon mb-3">🛒</div>
            <h3>Sales Tracking</h3>
            <p>Manage sales transactions with accurate reporting.</p>
        </div>
        <div class="col-md-4">
            <div class="icon mb-3">🔐</div>
            <h3>Secure Access</h3>
            <p>Role-based authentication for admins and cashiers.</p>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="text-center py-4">
    <p class="mb-0">&copy; <?= date('Y'); ?> VapeTrack CIOS. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>