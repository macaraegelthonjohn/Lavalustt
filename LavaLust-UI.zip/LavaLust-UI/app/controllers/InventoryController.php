<?php

namespace App\Controllers;

use Lavalust\Base\Controller;

class InventoryController extends Controller
{
    public function index()
    {
        return $this->call -> view('inventory');
    }
}
